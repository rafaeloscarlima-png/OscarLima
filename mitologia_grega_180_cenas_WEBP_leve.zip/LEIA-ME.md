# Mitologia grega — 180 imagens

Uma imagem por cena, em sequência de `cena_001` a `cena_180`.

- `imagens/`: PNGs originais, 1672 × 940 ou 941 px.
- `imagens_webp/`: versão compacta para revisão e montagem.
- `contato/`: seis folhas de contato, 30 quadros por folha.
- `cenas.json`: narração, ideia visual e duração planejada de cada cena.
- `roteiro_mitologia_grega_180_cenas.md`: roteiro completo em português.

Cada quadro é uma ilustração original baseada no roteiro, criada para se aproximar da linguagem visual geral da referência. A aparência e a continuidade dos personagens podem precisar de uma revisão adicional antes de uma animação final.
