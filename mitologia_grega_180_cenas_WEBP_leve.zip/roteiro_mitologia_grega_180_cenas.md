# Mitologia grega — roteiro visual de 180 cenas

Roteiro **original em português**, inspirado na sequência de temas do vídeo enviado. O trecho de gravação de tela alheio à mitologia foi retirado. As tradições gregas têm versões diferentes; este roteiro escolhe uma linha narrativa clara sem apresentá-la como a única.

**Formato:** 16:9; cerca de 15 minutos com locução deliberada (aproximadamente 110–120 palavras por minuto) e pausas curtas. Referência inicial de 5 segundos por cena. O texto de narração tem cerca de 1.500 palavras; em ritmo mais rápido, o filme ficará mais curto. A duração final deve acompanhar a locução, especialmente em nomes próprios. Cada linha contém a fala de narração e a imagem que a acompanha. Personagens e fundos devem ser reutilizados; os números indicam montagens, não desenhos inteiramente novos.

## 1. Abertura — cenas 001–010

| Nº | Narração | Ideia visual |
|---:|---|---|
| 001 | Antes dos templos, os gregos já contavam histórias sobre um mundo imprevisível. | Mapa antigo; pequenas figuras sob nuvens escuras. |
| 002 | Nessas histórias, deuses e mortais dividiam o mesmo céu. | Silhuetas humanas embaixo; figuras divinas acima. |
| 003 | O trovão tinha nome. O mar também tinha vontade. | Raio de Zeus; onda formando o tridente. |
| 004 | Até o medo, a fome e a esperança ganhavam rosto. | Três máscaras simples surgem uma a uma. |
| 005 | Mas não existe uma única versão de cada mito grego. | Dois rolos antigos mostram desenhos diferentes. |
| 006 | Poetas mudavam detalhes, enquanto as histórias atravessavam séculos. | Rolos passam de mão em mão pelo mapa. |
| 007 | Vamos seguir o fio que liga a origem aos heróis. | Um fio vermelho cruza retratos e lugares. |
| 008 | Ele começa antes de Zeus, antes dos próprios Titãs. | Retratos desaparecem até restar uma tela escura. |
| 009 | Começa quando ainda não havia terra nem céu. | Horizonte vazio; nenhuma forma definida. |
| 010 | No começo, havia o Caos. | Palavra CAOS sobre vazio azul-escuro. |

## 2. Origem do mundo — cenas 011–030

| Nº | Narração | Ideia visual |
|---:|---|---|
| 011 | Do Caos surgiram forças antigas, mais vastas que pessoas. | Formas abstratas emergem da escuridão. |
| 012 | Gaia tomou forma como a própria Terra. | Globo rochoso vira figura de Gaia. |
| 013 | Tártaro era o abismo profundo sob tudo o que existia. | Corte vertical do mundo mostra o abismo. |
| 014 | Eros trouxe a força que aproxima e transforma. | Dois pontos distantes se unem por luz. |
| 015 | Gaia gerou Urano, o céu que a cobria. | Céu estrelado curva-se sobre a terra. |
| 016 | Juntos, eles tiveram filhos de poderes imensos. | Silhuetas infantis enormes aparecem entre ambos. |
| 017 | Vieram os Titãs, ancestrais de muitos deuses. | Grupo de Titãs alinhado em fundo claro. |
| 018 | Vieram também Ciclopes e seres de cem braços. | Um olho; depois muitos braços em sombra. |
| 019 | Urano temeu esses filhos e os prendeu nas profundezas. | Urano fecha uma passagem sob a terra. |
| 020 | Gaia sofria, enquanto os filhos se agitavam dentro dela. | Terra racha ao redor de Gaia. |
| 021 | Ela pediu aos Titãs que enfrentassem o próprio pai. | Gaia entrega uma foice a mãos hesitantes. |
| 022 | Só Cronos aceitou a tarefa. | Cronos fica sozinho diante da foice. |
| 023 | Armado por Gaia, ele atacou Urano numa emboscada. | Sombras de Cronos e Urano; corte simbólico. |
| 024 | Céu e Terra se separaram para sempre. | Linha clara abre espaço entre céu e solo. |
| 025 | Do sangue derramado nasceram outras forças terríveis. | Gotas viram silhuetas de Fúrias e Gigantes. |
| 026 | E da espuma do mar nasceu Afrodite, segundo um relato. | Afrodite surge entre espuma e conchas. |
| 027 | Cronos assumiu o poder e tomou Reia por companheira. | Casal sobre trono simples, sem celebração. |
| 028 | Mas ouviu que um de seus filhos também o destronaria. | Profecia aparece atrás do trono. |
| 029 | Aterrorizado, engoliu cada criança assim que nasceu. | Cinco pequenas sombras desaparecem na boca escura. |
| 030 | Reia decidiu salvar o filho mais novo: Zeus. | Reia esconde um bebê; pedra embrulhada ao lado. |

## 3. Zeus e a guerra dos Titãs — cenas 031–058

| Nº | Narração | Ideia visual |
|---:|---|---|
| 031 | Reia entregou a Cronos uma pedra enrolada em panos. | Cronos recebe o embrulho sem olhar. |
| 032 | Enquanto isso, Zeus crescia escondido na ilha de Creta. | Mapa aproxima Creta e uma caverna. |
| 033 | Lá, vozes e tambores abafavam seu choro. | Guardiões batem escudos diante da caverna. |
| 034 | Anos depois, Zeus voltou para enfrentar o pai. | Zeus adulto encara o palácio de Cronos. |
| 035 | Com ajuda de Métis, fez Cronos libertar os irmãos. | Taça, reação de Cronos, cinco sombras escapam. |
| 036 | Primeiro saíram Héstia, Deméter e Hera. | Três irmãs aparecem contra fundo branco. |
| 037 | Depois vieram Hades e Poseidon. | Dois irmãos se juntam ao grupo. |
| 038 | A família reunida não tinha escolha: começaria uma guerra. | Irmãos de um lado; Titãs do outro. |
| 039 | Zeus libertou os Ciclopes presos no abismo. | Portões de pedra se abrem. |
| 040 | Em agradecimento, eles forjaram o raio para Zeus. | Martelo bate em metal; raio ganha forma. |
| 041 | Poseidon recebeu um tridente capaz de sacudir o mar. | Tridente risca a água em três linhas. |
| 042 | Hades ganhou um elmo que escondia sua presença. | Hades some atrás do próprio contorno. |
| 043 | A guerra entre deuses e Titãs ficou conhecida como Titanomaquia. | Nome sobre dois exércitos esquemáticos. |
| 044 | Ela durou dez anos, segundo a tradição mais conhecida. | Dez riscos surgem numa rocha. |
| 045 | Montanhas caíam, enquanto o céu brilhava com relâmpagos. | Montanha rachada; raio recorta as nuvens. |
| 046 | Nem Zeus conseguia vencer apenas com seus irmãos. | Seis deuses recuam diante de Titãs enormes. |
| 047 | Gaia aconselhou libertar também os seres de cem braços. | Gaia aponta para o abismo em mapa. |
| 048 | Eles lançaram pedras como uma tempestade sem fim. | Várias mãos arremessam rochas em sequência. |
| 049 | Por fim, os Titãs perderam a batalha. | Coroas e armas caem no chão. |
| 050 | Cronos e seus aliados foram presos no Tártaro. | Grades fecham sobre silhuetas titânicas. |
| 051 | Atlas recebeu uma punição diferente: sustentar o céu. | Atlas pequeno sob abóbada imensa. |
| 052 | Zeus, Poseidon e Hades sortearam seus domínios. | Três pedras são retiradas de uma tigela. |
| 053 | Zeus ficou com o céu e comandou o Olimpo. | Zeus no alto da montanha. |
| 054 | Poseidon tomou os mares, sempre inquietos. | Poseidon entre ondas e navios pequenos. |
| 055 | Hades passou a governar o mundo dos mortos. | Hades diante de portão subterrâneo. |
| 056 | A Terra, porém, continuou sendo palco de todos. | Mapa da Terra entre os três domínios. |
| 057 | Nem a vitória encerrou as ameaças aos novos deuses. | Sombra monstruosa cresce atrás do Olimpo. |
| 058 | E a próxima disputa envolveria criaturas ainda mais frágeis: humanos. | Pequena figura humana sob sombra divina. |

## 4. Humanos, fogo e Pandora — cenas 059–082

| Nº | Narração | Ideia visual |
|---:|---|---|
| 059 | Em uma versão, Prometeu moldou seres humanos do barro. | Mãos de Prometeu modelam pequenas figuras. |
| 060 | Atena lhes deu vida e inteligência. | Atena sopra luz sobre as figuras de barro. |
| 061 | Eram pequenos diante dos animais e das tempestades. | Humanos encolhidos ao pé de nuvens grandes. |
| 062 | Prometeu escolheu ajudá-los, mesmo contrariando Zeus. | Prometeu coloca-se entre Zeus e os humanos. |
| 063 | Num sacrifício, ele enganou Zeus com duas oferendas. | Duas pilhas cobertas sobre uma mesa. |
| 064 | A melhor carne ficou com os mortais. | Humanos descobrem alimento sob a primeira cobertura. |
| 065 | Zeus, furioso, tirou deles o fogo. | Última chama humana apaga. |
| 066 | Sem fogo, cada noite parecia maior. | Pequenos humanos tremem ao redor de cinzas. |
| 067 | Prometeu roubou uma chama do domínio divino. | Chama escondida no interior de um caule. |
| 068 | E a devolveu aos humanos, dentro de uma haste. | Prometeu entrega luz a mãos humanas. |
| 069 | Com ela vieram calor, comida cozida e ferramentas. | Três vinhetas: fogueira, panela e forja. |
| 070 | Zeus puniu Prometeu por desafiar sua ordem. | Correntes prendem Prometeu a um rochedo. |
| 071 | Uma ave devorava seu fígado, que voltava a crescer. | Ave em sombra; ferida apenas sugerida. |
| 072 | A punição se repetia, dia após dia. | Sol e lua giram sobre o rochedo. |
| 073 | Zeus também mandou criar Pandora, cheia de dons. | Deuses oferecem pequenos símbolos a Pandora. |
| 074 | Ela recebeu um recipiente que não deveria abrir. | Vaso selado diante de Pandora. |
| 075 | A curiosidade venceu, e a tampa se ergueu. | Mão hesitante levanta a tampa. |
| 076 | Dali escaparam doença, trabalho e tantas outras dores. | Fumaça vira máscaras de tristeza e doença. |
| 077 | No fundo, restou a esperança. | Pequena luz permanece dentro do vaso. |
| 078 | Os mitos agora explicavam uma vida humana difícil. | Família trabalha sob sol e chuva. |
| 079 | Em outra história, Zeus julgou a humanidade corrompida. | Zeus observa aldeias de uma nuvem. |
| 080 | Enviou então um dilúvio que cobriu a Terra. | Chuva engole casas em mapa simples. |
| 081 | Deucalião e Pirra sobreviveram numa pequena embarcação. | Casal em barco cercado de água. |
| 082 | Ao lançar pedras para trás, deram origem a novos humanos. | Pedras no chão viram pequenas silhuetas. |

## 5. Heróis e monstros — cenas 083–147

### Perseu — cenas 083–096

| Nº | Narração | Ideia visual |
|---:|---|---|
| 083 | Uma profecia avisou Acrísio: seu neto causaria sua morte. | Rei lê profecia; sombra de criança ao fundo. |
| 084 | Ele tentou impedir que a filha Dânae tivesse filhos. | Dânae atrás de porta trancada. |
| 085 | Mas Zeus chegou até ela, e nasceu Perseu. | Luz dourada; bebê aparece ao lado de Dânae. |
| 086 | Acrísio lançou mãe e filho ao mar numa arca. | Arca pequena sobre ondas enormes. |
| 087 | Ambos sobreviveram e chegaram à ilha de Sérifos. | Arca encalha numa praia. |
| 088 | Ali, um rei exigiu de Perseu a cabeça de Medusa. | Rei aponta para desenho de Medusa. |
| 089 | O olhar da Górgona transformava pessoas em pedra. | Estátuas diante de olhos escondidos. |
| 090 | Com ajuda divina, Perseu encontrou o caminho até ela. | Trilha marcada por sandálias e espada. |
| 091 | Escudo espelhado e outros presentes o protegeriam. | Equipamentos surgem um a um sobre mesa. |
| 092 | Ele avançou olhando apenas o reflexo no escudo. | Reflexo de Medusa no metal; Perseu de costas. |
| 093 | Cortou sua cabeça sem encarar seus olhos. | Ação sugerida por sombra e corte rápido. |
| 094 | Do sangue de Medusa surgiu Pégaso, o cavalo alado. | Pégaso aparece em silhueta sobre céu claro. |
| 095 | Voltando para casa, Perseu salvou Andrômeda de um monstro marinho. | Andrômeda numa rocha; monstro no mar. |
| 096 | Mais tarde, um acidente cumpriu a profecia sobre Acrísio. | Disco lançado; destino indicado por sombra. |

### Héracles — cenas 097–121

| Nº | Narração | Ideia visual |
|---:|---|---|
| 097 | Outro filho de Zeus nasceu mortal: Héracles. | Bebê diante de duas figuras parentais. |
| 098 | Hera odiava a lembrança da infidelidade do marido. | Hera observa o bebê com rosto tenso. |
| 099 | Ainda criança, Héracles venceu serpentes enviadas contra ele. | Berço; duas serpentes contidas pelo bebê. |
| 100 | Cresceu com força extraordinária, mas uma vida instável. | Héracles levanta pedra; família distante. |
| 101 | Num acesso de loucura provocado por Hera, matou a própria família. | Tragédia mostrada por portas fechando e sombras. |
| 102 | Buscando reparação, aceitou servir ao rei Euristeu. | Héracles ajoelha-se diante de trono simples. |
| 103 | Primeiro, venceu o leão de Nemeia e tomou sua pele. | Leão em sombra; manto sobre Héracles. |
| 104 | Depois enfrentou a Hidra, cujas cabeças tornavam a crescer. | Cabeças da Hidra se multiplicam. |
| 105 | Perseguiu a corça de Cerineia sem poder matá-la. | Corça corre entre árvores; Héracles atrás. |
| 106 | Capturou vivo o feroz javali de Erimanto. | Javali preso em rede diante da montanha. |
| 107 | Limpou os estábulos de Áugias desviando dois rios. | Água atravessa estábulos abarrotados. |
| 108 | Espantou as aves de Estínfalo com armas e ruído. | Bando escuro levanta voo sobre o lago. |
| 109 | Dominou o touro de Creta e o trouxe de volta. | Héracles segura touro por uma corda. |
| 110 | Controlou as éguas violentas do rei Diomedes. | Cavalos inquietos atrás de cerca quebrada. |
| 111 | Buscou o cinturão da rainha das Amazonas, Hipólita. | Cinturão dourado entre Héracles e Hipólita. |
| 112 | Roubou o gado guardado pelo gigante Gerião. | Gado atravessa mapa; gigante ao longe. |
| 113 | Encontrou as maçãs douradas das Hespérides. | Três frutos brilham entre galhos escuros. |
| 114 | Por fim, trouxe Cérbero vivo do mundo dos mortos. | Cérbero sai do portão subterrâneo. |
| 115 | Os trabalhos terminaram, mas o sofrimento de Héracles continuou. | Lista concluída; sombra ainda cobre o herói. |
| 116 | Suas flechas carregavam o veneno mortal da Hidra. | Flecha toca um pequeno frasco verde. |
| 117 | Um centauro chamado Nesso atacou sua esposa, Dejanira. | Confronto à margem de um rio. |
| 118 | Morrendo, Nesso mentiu sobre o poder de seu sangue. | Nesso entrega tecido; palavra AMOR se desfaz. |
| 119 | Dejanira enviou uma túnica que queimou a pele de Héracles. | Túnica envolta em fumaça; dor sugerida. |
| 120 | Incapaz de suportá-la, o herói subiu à própria pira. | Héracles em silhueta entre chamas simbólicas. |
| 121 | Sua parte mortal morreu; a divina alcançou o Olimpo. | Silhueta se divide entre cinzas e luz. |

### Teseu — cenas 122–133

| Nº | Narração | Ideia visual |
|---:|---|---|
| 122 | Em Atenas, Teseu provou sua origem erguendo uma pedra. | Espada e sandálias aparecem sob a pedra. |
| 123 | Seguiu então pela estrada, vencendo perigos no caminho. | Pequeno mapa com marcas de confrontos. |
| 124 | Ao chegar, descobriu o tributo exigido por Creta. | Jovens atenienses diante de navio. |
| 125 | A cada período, jovens eram enviados ao Minotauro. | Sombra do Minotauro projetada no labirinto. |
| 126 | Teseu embarcou decidido a interromper aquele sacrifício. | Teseu no convés com vela negra. |
| 127 | Em Creta, Ariadne lhe entregou um novelo de fio. | Ariadne estende fio vermelho para Teseu. |
| 128 | O fio marcaria a saída do labirinto. | Linha vermelha desenha corredor intrincado. |
| 129 | Lá dentro, Teseu enfrentou e venceu o Minotauro. | Silhuetas de luta entre muros altos. |
| 130 | Guiado pelo fio, voltou à luz com os outros jovens. | Grupo emerge seguindo o fio. |
| 131 | Ariadne fugiu com ele, mas foi deixada numa ilha. | Ariadne sozinha; navio afasta-se. |
| 132 | Teseu esqueceu de trocar a vela negra do navio. | Vela negra se aproxima da costa. |
| 133 | Seu pai, Egeu, pensou que ele morrera e caiu ao mar. | Egeu vê a vela da muralha; queda sugerida. |

### Édipo — cenas 134–143

| Nº | Narração | Ideia visual |
|---:|---|---|
| 134 | Outra profecia dizia que Édipo mataria o pai e casaria com a mãe. | Oráculo; duas silhuetas familiares se cruzam. |
| 135 | Seus pais o abandonaram ainda bebê para impedir o destino. | Bebê deixado à distância, sem violência explícita. |
| 136 | Criado em Corinto, Édipo desconhecia sua origem. | Duas famílias em lados opostos do mapa. |
| 137 | Ao ouvir a profecia, fugiu de quem julgava seus pais. | Édipo parte por estrada bifurcada. |
| 138 | Numa encruzilhada, matou um homem após uma disputa. | Carruagem e Édipo; confronto em silhueta. |
| 139 | Era Laio, seu pai biológico, mas Édipo não sabia. | Retrato de Laio se liga ao bebê por fio. |
| 140 | Perto de Tebas, respondeu ao enigma da Esfinge. | Esfinge diante de Édipo; interrogação no ar. |
| 141 | Recebeu o trono e se casou com a rainha Jocasta. | Coroa sobre casal diante de Tebas. |
| 142 | Uma peste revelou que Jocasta também era sua mãe. | Fios de parentesco fecham um círculo. |
| 143 | Jocasta morreu; Édipo cegou-se e deixou a cidade. | Porta se fecha; Édipo caminha de olhos cobertos. |

### Transição — cenas 144–147

| Nº | Narração | Ideia visual |
|---:|---|---|
| 144 | Vitória e tragédia andavam juntas nessas histórias. | Duas máscaras, uma vitoriosa e outra triste. |
| 145 | Os deuses continuavam interferindo nas escolhas humanas. | Mãos divinas movem pequenas peças num mapa. |
| 146 | Num casamento divino, uma convidada ficou de fora: Éris. | Banquete luminoso; Éris parada à porta. |
| 147 | Sua vingança começaria a maior guerra dos heróis gregos. | Maçã dourada rola em direção a Troia. |

## 6. A Guerra de Troia — cenas 148–175

| Nº | Narração | Ideia visual |
|---:|---|---|
| 148 | Os deuses celebravam o casamento de Peleu e Tétis. | Mesa de banquete com deuses e recém-casados. |
| 149 | Éris lançou uma maçã marcada: para a mais bela. | Maçã dourada cai no centro da mesa. |
| 150 | Hera, Atena e Afrodite reivindicaram o prêmio. | Três deusas apontam para a maçã. |
| 151 | Zeus entregou a decisão a Páris, príncipe de Troia. | Páris diante das três deusas. |
| 152 | Hera lhe ofereceu poder sobre grandes reinos. | Coroas surgem atrás de Hera. |
| 153 | Atena prometeu vitória e sabedoria na guerra. | Elmo e tabuleiro de batalha atrás de Atena. |
| 154 | Afrodite prometeu o amor da mulher mais bela. | Silhueta de Helena aparece entre pétalas. |
| 155 | Páris escolheu Afrodite e ganhou duas inimigas divinas. | Maçã vai a Afrodite; outras deusas se afastam. |
| 156 | Helena, porém, já era esposa de Menelau, rei de Esparta. | Helena e Menelau diante de palácio. |
| 157 | Páris levou Helena para Troia, iniciando a crise. | Navio se afasta de Esparta rumo a Troia. |
| 158 | Menelau chamou os antigos pretendentes de Helena para lutar. | Mensageiros convocam reis no mapa grego. |
| 159 | Uma enorme frota partiu em direção à costa troiana. | Fileiras de navios preenchem o mar. |
| 160 | Antes da partida, ventos contrários prenderam os gregos em Áulis. | Velas caídas; mar parado sob nuvem. |
| 161 | Algumas versões ligam a mudança dos ventos ao sacrifício de Ifigênia. | Ifigênia em silhueta; corte para vento nas velas. |
| 162 | Quando chegaram, os gregos encontraram muralhas difíceis de vencer. | Frota diante dos muros altos de Troia. |
| 163 | A guerra avançou por quase dez anos entre ataques e perdas. | Calendário de dez marcas; campo muda de estação. |
| 164 | Entre os gregos, Aquiles era o guerreiro mais temido. | Aquiles avança; inimigos recuam. |
| 165 | Mas uma disputa com Agamêmnon o afastou do combate. | Aquiles abandona a tenda de comando. |
| 166 | Sem ele, a batalha se voltou contra os gregos. | Tropas gregas recuam até os navios. |
| 167 | Pátroclo vestiu a armadura de Aquiles para ajudá-los. | Pátroclo fecha o elmo diante de Aquiles. |
| 168 | Heitor, príncipe de Troia, matou Pátroclo na luta. | Heitor e Pátroclo em silhueta; elmo cai. |
| 169 | Tomado pelo luto, Aquiles voltou ao campo de batalha. | Aquiles diante da armadura vazia. |
| 170 | Ele matou Heitor, mas não podia salvar o amigo. | Aquiles e Heitor; transição para Pátroclo. |
| 171 | Aquiles também morreria; versões posteriores destacariam seu calcanhar. | Flecha em sombra; brilho no tornozelo. |
| 172 | Sem vitória decisiva, os gregos buscaram outra saída. | Generais observam os muros num mapa. |
| 173 | Odisseu propôs esconder guerreiros dentro de um cavalo de madeira. | Planta simples do cavalo com compartimento. |
| 174 | Os troianos levaram o presente para dentro da cidade. | Cavalo atravessa o portão entre comemorações. |
| 175 | À noite, os guerreiros saíram; Troia caiu em chamas. | Portas se abrem; cidade arde ao longe. |

## 7. Encerramento — cenas 176–180

| Nº | Narração | Ideia visual |
|---:|---|---|
| 176 | Os sobreviventes partiram, carregando perdas para novas histórias. | Navios se afastam da costa de Troia. |
| 177 | Nem deuses nem heróis saíram ilesos desse mundo. | Retratos do elenco com marcas e sombras. |
| 178 | Cada mito perguntava quem decide uma vida: força, escolha ou destino. | Mão, caminho e fio da profecia lado a lado. |
| 179 | Por isso, as histórias mudaram, mas continuaram sendo contadas. | Rolos antigos passam a novos narradores. |
| 180 | E o Olimpo ainda vive onde alguém volta a narrá-las. | Narrador diante do mapa; estrelas apagam devagar. |

## Direção de produção

- **Locução:** tom narrativo, claro e levemente sombrio. Deixar pequenas pausas após profecias, mortes e viradas; não acelerar nomes para forçar cinco segundos exatos.
- **Imagem:** traço preto irregular, rostos brancos expressivos, corpos simples, membros finos, cores chapadas e cenários econômicos. A escuridão aparece sobretudo em luz, fundo e composição; o personagem continua legível.
- **Montagem:** mapas para deslocamentos, fundo branco para explicações, cenários completos para acontecimentos centrais. Usar movimentos leves de câmera e trocar expressão ou pose quando a mesma base reaparecer.
- **Som:** temas musicais originais discretos; efeitos pontuais de vento, mar, metal, fogo e silêncio nas tragédias. Evitar cobrir nomes próprios na fala.
- **Próxima etapa:** gravar uma locução piloto dos primeiros 30 quadros, medir a duração real e ajustar tempos antes de produzir todas as imagens.
